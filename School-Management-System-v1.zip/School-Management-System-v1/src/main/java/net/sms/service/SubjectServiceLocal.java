
package net.sms.service;

import net.sms.model.Classroom;
import net.sms.model.School;
import net.sms.model.Subject;
import net.sms.persistence.BaseDAO;

/**
 *
 * @author Gershom.Maluleke
 */

public interface SubjectServiceLocal extends BaseDAO<Subject>{
    
}
