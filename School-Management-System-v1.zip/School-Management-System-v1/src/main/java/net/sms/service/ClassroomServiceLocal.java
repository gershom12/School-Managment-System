
package net.sms.service;

import net.sms.model.Classroom;
import net.sms.persistence.BaseDAO;

/**
 *
 * @author Gershom.Maluleke
 */

public interface ClassroomServiceLocal extends BaseDAO<Classroom>{
    
}
