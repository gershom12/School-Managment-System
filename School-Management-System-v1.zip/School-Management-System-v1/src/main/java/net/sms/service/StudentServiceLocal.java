
package net.sms.service;

import net.sms.model.Classroom;
import net.sms.model.School;
import net.sms.model.Student;
import net.sms.persistence.BaseDAO;

/**
 *
 * @author Gershom.Maluleke
 */

public interface StudentServiceLocal extends BaseDAO<Student>{
    
}
