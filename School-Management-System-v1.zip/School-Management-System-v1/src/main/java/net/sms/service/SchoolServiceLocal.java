
package net.sms.service;

import net.sms.model.School;
import net.sms.persistence.BaseDAO;

/**
 *
 * @author Gershom.Maluleke
 */

public interface SchoolServiceLocal extends BaseDAO<School>{
    
}
